### A Century of Conservation: The Ongoing Recovery of Svalbard Reindeer 
### Le Moullec et al. 2019, Journal of Wildlife Management
### DRYAD data link: 
### Cite as: Le Moullec, Mathilde et al. (2020), Data from: A century of conservation: the ongoing recovery of Svalbard reindeer, Dryad, Dataset, https://doi.org/10.5061/dryad.7351kt1

# Set working directory
setwd(" SET YOUR WORKING DIRECTORY")
########## Packages ########
require(Distance) # for DS detection function
require(dsm) # for DS density function
require(lmtest) # TC model fit LogLik
require(pscl) # TC Hurdle model
require(scales) # graph color alpha
require(MASS) # TS simulation mvrnorm
########## Functions ###########
make_table <- function(model){
  # this function extracts the model data for a single model (row)
  extract_model_data <- function(model){
    c(summary(model)$ds$key,
      model$ddf$ds$aux$ddfobj$scale$formula,
      model$ddf$criterion,
      ddf.gof(model$ddf, qq=FALSE)$dsgof$CvM$p,
      summary(model)$ds$average.p,
      summary(model)$ds$average.p.se
    )
  }
  # applying that to all the models then putting it into a data.frame
  res <- as.data.frame(t(as.data.frame(lapply(model, extract_model_data))),
                       stringsAsFactors=FALSE)
  # making sure the correct columns are numeric
  res[,3] <- as.numeric(res[,3])
  res[,4] <- as.numeric(res[,4])
  res[,5] <- as.numeric(res[,5])
  res[,6] <- as.numeric(res[,6])
  
  # giving the columns names
  colnames(res) <- c("Key function", "Formula", "AIC", "Cramer-von Mises $p$-value",
                     "$\\hat{P_a}$", "se($\\hat{P_a}$)")
  # creating a new column for the AIC difference to the best model
  res[["Delta_AIC"]] <- res$AIC - min(res$AIC, na.rm=TRUE)
  # ordering the model by AIC score
  res <- res[order(res$AIC),]
  res<-res[,c(1,2,3,7)] # For NOW, just to report AIC table
  # returning the data.frame
  return(res)
}

######## Data  #######
### Read the legend text in the Excel file
# The data are already truncated to a distance of 908m
# reindeer clusters observed in each segmented transects (transect segmentation done in another script). Do not includ segments without observations:
#DS
Obs_seg<-read.delim(file="Distance_sampling_segment_data_for_Distance_detection_fonction.txt",sep="\t")
head(Obs_seg)
Seg_data<-read.delim(file="Distance_sampling_segment_data_for_dsm.txt",sep="\t")
head(Seg_data)

#TC
TCforGLM<-read.delim(file="TotalCounts_HurdleModels.txt",sep=";")
head(TCforGLM)

# # Prediction tables
### Ask Mathilde Le Moullec if interested mathilde.lemoullec@ntnu.no
# Pred.table<-read.delim(file="Svalbard_Pred.table_LeMoullec2019.txt",sep="\t")
# head(Pred.table)
# SYSArea_pred.table<-read.delim("SYSArea_pred.table_LeMoullec2019.txt",sep=";")
# head(SYSArea_pred.table)

####### DISTANCE SAMPLING ######
####### ~ Data exploration #######
### observations
hist(Obs_seg$distance,breaks=5)
max(na.omit(Obs_seg$distance))# 907m after truncation
length(Obs_seg$size) # 489 clusters in the covered area and after truncation (908m)
sum(Obs_seg$size) # 866 reindeer individulas in the covered area and after truncation (908m)
mean(Obs_seg$size) # 1.77
sd(Obs_seg$size) #1.16
plot(Obs_seg$size~Obs_seg$distance)
abline(lm(Obs_seg$size~Obs_seg$distance))
cor.test(Obs_seg$size,Obs_seg$distance)

### Segments
length(Seg_data$Sample.Label)# 189 segments
(sum(Seg_data$Effort)*908*2)*10^-6 # ~ 540 km2 DS covered area
((sum(Seg_data$Effort[Seg_data$Extinct==0])*908*2)*10^-6)*100/((sum(Seg_data$Effort[Seg_data$Extinct==0])*908*2)*10^-6+(sum(Seg_data$Effort[Seg_data$Extinct==1])*908*2)*10^-6)# 70% of DS cover area within extirpated land
mean(Seg_data$NDVI)/1000 # 0.43 mean NDVI
sd(Seg_data$NDVI)/1000 # 0.14 SE NDVI
min(Seg_data$NDVI)/1000 # 0.07
max(Seg_data$NDVI)/1000 # 0.72

###### ~ Detection function #########
# Use datafile where the segments without observations are removed
# The 5% truncation distance is 908.05m (95% quantile of all distances)
truncation<-list(left="0%",right=908.05) # dataset already truncated but the function require a measure

### Stepwise model selection 
### Step 1
# model<-list()
# model$hr.rug<-ds(Obs_seg,formula= ~ RUGG,truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.rug<-ds(Obs_seg,formula= ~ RUGG,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hr.obs<-ds(Obs_seg,formula= ~ Observer,truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.obs<-ds(Obs_seg,formula= ~ Observer,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hr.ho<-ds(Obs_seg,formula= ~ Horizon,truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.ho<-ds(Obs_seg,formula= ~ Horizon,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hr.sun<-ds(Obs_seg,formula= ~ weather,truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.sun<-ds(Obs_seg,formula= ~ weather,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hr.wind<-ds(Obs_seg,formula= ~ wind,truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.wind<-ds(Obs_seg,formula= ~ wind,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hr.yr<-ds(Obs_seg,formula= ~ as.factor(Year),truncation=truncation,transect="line",key="hr", adjustment=NULL)#
# model$hn.yr<-ds(Obs_seg,formula= ~ as.factor(Year),truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# make_table(model)
# 
# ### Step 2
# hn.null<-ds(Obs_seg,formula= ~ 1,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# hn.null.cos<-ds(Obs_seg,formula= ~ 1,truncation=truncation,transect="line",key="hn", adjustment="cos")#
# hn.null.poly<-ds(Obs_seg,formula= ~ 1,truncation=truncation,transect="line",key="hn", adjustment="poly")#
# model<-list()
# model$hn.null<-ds(Obs_seg,formula= ~ 1,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hn.rug<-ds(Obs_seg,formula= ~ RUGG,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hn.sun<-ds(Obs_seg,formula= ~ weather,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# model$hn.rug.sun<-ds(Obs_seg,formula= ~ RUGG + weather,truncation=truncation,transect="line",key="hn", adjustment=NULL)#
# make_table(model)

### Selected model
mod.sel<-ds(Obs_seg,formula= ~ as.factor(weather) ,truncation=truncation,transect="line",key="hn", adjustment=NULL) # Best when 250 or 500m seg
summary(mod.sel)
ddf.gof(mod.sel$ddf)
plot(mod.sel)
# ### Plots
# par(mfrow=c(2,3))
# plot(model$hn.sun, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Weather")
# plot(model$hn.rug, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Ruggedness")
# plot(model$hn.ho, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Walking horizon (low to high=Sea/Mount/horizon)")
# plot(model$hn.yr, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Year")
# plot(model$hn.wind, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Wind (low to high=<5m.s/>5m.s)")
# plot(model$hn.obs, which=2,pl.den=0,pl.ang=0,nc=31.76,main="Observer (low to high=MLM/BBH/MB/MK)")
# dev.off()

#tiff("Figure_2A.tiff", res = 300, width=6, height=7, units="in", compression="lzw+p")
par(mar=(c(5,5,4,4)+0.1),bty="n")
plot(mod.sel,which=2,axes=FALSE,xlab = "") #problem with removing ylab ??
axis(1,cex.axis=1.5,at=seq(0,1000,200),line=-0.8)
axis(2,cex.axis=1.5,line=-0.8)
mtext(1, text= "Distance (m)", line=1.6, cex=1.5,family="sans")
mtext(2, text= "Detection probability",line=1.6, cex=1.5)
text(1020,0.23,"Sunny", cex=1.2,xpd=NA) #,xpd=NA to write outside the margin
text(1020,0.14,"Mix", cex=1.2,xpd=NA)
text(1020,0.04,"Cloudy", cex=1.2,xpd=NA)
dev.off()

######### ~ Density Function ###########
### Backward model selection approach
# SK_full<-dsm(Nhat~NDVI + x + y + as.factor(Extinct),family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score
# summary(SK_full)
# SK<-dsm(Nhat~NDVI + x + as.factor(Extinct),family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score
# summary(SK)
# SK1<-dsm(Nhat~NDVI + x,family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score
# summary(SK1)
# SK2<-dsm(Nhat~NDVI ,family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score
# summary(SK2)
# SK0<-dsm(Nhat~1 ,family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score
# summary(SK0)
# Selected model: 
SK1<-dsm(Nhat~NDVI + x,family=quasipoisson(link = "log"),engine = "gam",method="REML", mod.sel$ddf, segment.data=Seg_data, observation.data=Obs_seg, group=FALSE) # aim for low GCV score 
summary(SK1)

### Model check
par(mfrow=c(2,2))
gam.check((SK1))
dev.off()
ar(residuals(SK1))# residual correlation 1 lag

### ~ Prediction Svalbard ####
head(Pred.table)
PredDS<-dsm.var.gam(SK1,Pred.table,off.set=240*240)# Set off.set according to resolution
summary(PredDS)
unlist(PredDS$pred) # 21079
sqrt(PredDS$pred.var) # 2983
cv<-sqrt(PredDS$pred.var)/unlist(PredDS$pred)

#### ~ Prediction curve density ####
NDVI.seq=seq(1,1000,1)
head(Pred.table)
mean.x<-mean(Pred.table$x)# keep covariate x fix 
NewDS=data.frame(NDVI=NDVI.seq,x=mean.x)

DSp<-predict(SK1,newdata=NewDS,off.set=240*240,se.fit=TRUE)
DSpred<-DSp$fit
DSpred.se<-DSp$se.fit
# See the plot in section 'COMBINE DS and TC'
#### ~ Predict management areas ####

######## TOTAL COUNTS #######
head(TCforGLM) # A = Extirpated 0 ; B = not extirpated 1. 
# variables x and y are scaled (/10000 and /100000 respectively) to unable the model to run
#### ~ overdispertion ? ####
ZAP<-hurdle(TCforGLM$obs~TCforGLM$NDVI|TCforGLM$NDVI,dist="poisson",link="logit") # Before | = cov of count process, after | = cov of presence-Absence process
ZANB<-hurdle(obs~NDVI|NDVI,data=TCforGLM,dist="negbin",link="logit")
summary(ZAP)
summary(ZANB)
lrtest(ZAP,ZANB) # negbin required
# #Df  LogLik Df  Chisq Pr(>Chisq)    
# 1   4 -7083.5                         # ZAP
# 2   5 -6275.8  1 1615.5  < 2.2e-16 ***#ZANB

#### ~ model selection ####
# model<-list()
#  model$ZANB1<-hurdle(obs~NDVI+x+Extinct+y|NDVI+x+Extinct+y,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB2<-hurdle(obs~NDVI+x+Extinct|NDVI+x+Extinct+y,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB3<-hurdle(obs~NDVI+x+Extinct+y|NDVI+x+Extinct,data=TCforGLM,dist="negbin",link="logit")
# 
#  model$ZANB4<-hurdle(obs~NDVI+x+Extinct|NDVI+x+Extinct,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB5<-hurdle(obs~NDVI+x|NDVI+x+Extinct,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB6<-hurdle(obs~NDVI+x+Extinct|NDVI+x,data=TCforGLM,dist="negbin",link="logit")
# 
#  model$ZANB7<-hurdle(obs~NDVI+x|NDVI+x,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB8<-hurdle(obs~NDVI|NDVI+x,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB9<-hurdle(obs~NDVI+x|NDVI,data=TCforGLM,dist="negbin",link="logit")
# 
#  model$ZANB10<-hurdle(obs~NDVI|NDVI,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB11<-hurdle(obs~NDVI|1,data=TCforGLM,dist="negbin",link="logit")
#  model$ZANB12<-hurdle(obs~1|NDVI,data=TCforGLM,dist="negbin",link="logit")
# 
#  model$ZANB13<-hurdle(obs~1|1,data=TCforGLM,dist="negbin",link="logit")
# 
# AIC.data <- lapply(X = model, FUN = AIC)
# mod.tab<-data.frame(model=names(model),AIC=as.numeric(AIC.data),para=c(10,9,9,8,7,7,6,5,5,4,3,3,2))
# mod.tab<-mod.tab[order(mod.tab$AIC),]
# mod.tab$deltaAIC<-round(mod.tab[,2]-mod.tab[1,2],2)
# mod.tab #We selected the model with least parameters and a ??AIC <2 which correspond to ZANB4
# Selected model
ZANB<-hurdle(obs~NDVI+x+Extinct|NDVI+x+Extinct,data=TCforGLM,dist="negbin",link="logit")
summary(ZANB) # recall to rescale coefs for x and y

#for Table S6
summary(model$ZANB3)
summary(model$ZANB4)
summary(model$ZANB1)

#### ~ Prediction Svalbard ####
head(Pred.table)
Pred.tableTC<-Pred.table
Pred.tableTC$x<-Pred.tableTC$x/10000 #rescale 
Pred.tableTC$y<-Pred.tableTC$y/100000 # rescale
head(Pred.tableTC)
#First predict in Extirpated areas, then in not extirpated areas
### Exctinction = 0 
#PA model
Pred.tableTCA<-Pred.tableTC[Pred.tableTC$Extinct=="0",]
PA<-coef(ZANB,model="zero") # PA part
g<-PA[1]+PA[2]*Pred.tableTCA$NDVI+PA[3]*Pred.tableTCA$x+0 # region A
p<-exp(g)/(1+exp(g)) #backtrasform of logit 
#Count model
theta<-ZANB$theta
Cnt<-coef(ZANB,model="count") # count part
gc<-Cnt[1]+Cnt[2]*Pred.tableTCA$NDVI+Cnt[3]*Pred.tableTCA$x+0 # region A
mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
# Combine
Po<-(theta/(mu1+theta))^theta 
muZANB.A<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1
varZANB.A<-(p/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-((p/(1-Po))*mu1)^2 # # NOT AS IN ZUUR p 288:((1-p)/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-(((1-p)/(1-Po))*mu1)^2

### Exctinction = B Not extinct
Pred.tableTCB<-Pred.tableTC[Pred.tableTC$Extinct=="1",]
g<-PA[1]+PA[2]*Pred.tableTCB$NDVI+PA[3]*Pred.tableTCB$x+PA[4] # region B
p<-exp(g)/(1+exp(g)) #backtrasform of logit 
#Count model
gc<-Cnt[1]+Cnt[2]*Pred.tableTCB$NDVI+Cnt[3]*Pred.tableTCB$x+Cnt[4] # region B
mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
# Combine
Po<-(theta/(mu1+theta))^theta 
muZANB.B<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1
varZANB.B<-(p/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-((p/(1-Po))*mu1)^2 # # NOT AS IN ZUUR p 288:((1-p)/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-(((1-p)/(1-Po))*mu1)^2

sum(muZANB.A)+sum(muZANB.B) # total 22615
varTC<-sum(varZANB.A)+sum(varZANB.B) 
sqrt(sum(varZANB.A)+sum(varZANB.B)) #401

#### ~ Prediction curve ####
NDVI.seq=seq(1,1000,1)
mean.x<-mean(Pred.tableTC$x) # fixed covaraite (here scaled)

### Exctinction = A 
#PA model
PA<-coef(ZANB,model="zero") # PA part
g<-PA[1]+PA[2]*NDVI.seq+PA[3]*mean.x+0 # region A
p<-exp(g)/(1+exp(g)) #backtrasform of logit 
#Count model
theta<-ZANB$theta
Cnt<-coef(ZANB,model="count") # count part
gc<-Cnt[1]+Cnt[2]*NDVI.seq+Cnt[3]*mean.x+0 # region A
mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
# Combine
Po<-(theta/(mu1+theta))^theta 
muZANB.A<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1

### Exctinction = B
#PA model
PA<-coef(ZANB,model="zero") # PA part
g<-PA[1]+PA[2]*NDVI.seq+PA[3]*mean.x+PA[4] # region B
p<-exp(g)/(1+exp(g)) #backtrasform of logit 
#Count model
theta<-ZANB$theta
Cnt<-coef(ZANB,model="count") # count part
gc<-Cnt[1]+Cnt[2]*NDVI.seq+Cnt[3]*mean.x+Cnt[4] # region B
mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
# Combine
Po<-(theta/(mu1+theta))^theta 
muZANB.B<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1
# See plot in section COMBINE
#### Simulation of uncertainties 

Sigma.PA <- vcov(ZANB)[5:8,5:8]
Sigma.Cnt<- vcov(ZANB)[1:4,1:4]

PA.est<-mvrnorm(n = 10000*1000, mu=c(PA[1],PA[2],PA[3],PA[4]), Sigma.PA, empirical = TRUE)
Cnt.est<-mvrnorm(n = 10000*1000, mu=c(Cnt[1],Cnt[2],Cnt[3],Cnt[4]), Sigma.Cnt, empirical = TRUE)

head(PA.est)
head(Cnt.est)

PA.Int.est<-matrix(PA.est[,1], nrow=10000, ncol=1000)
PA.slope.est<-matrix(PA.est[,2], nrow=10000, ncol=1000)
Cnt.Int.est<-matrix(Cnt.est[,1], nrow=10000, ncol=1000)
Cnt.slope.est<-matrix(Cnt.est[,2], nrow=10000, ncol=1000)
PA.x.est<-matrix(PA.est[,3], nrow=10000, ncol=1000)
Cnt.x.est<-matrix(Cnt.est[,3], nrow=10000, ncol=1000)
PA.ExtB.est<-matrix(PA.est[,4], nrow=10000, ncol=1000)
Cnt.ExtB.est<-matrix(Cnt.est[,4], nrow=10000, ncol=1000)

p.estA<-matrix(NA, nrow=10000, ncol=1000)
mu1.estA<-matrix(NA, nrow=10000, ncol=1000)                                                
mu.estA<-matrix(NA, nrow=10000, ncol=1000)       
Po.estA<-matrix(NA, nrow=10000, ncol=1000)   

p.estB<-matrix(NA, nrow=10000, ncol=1000)
mu1.estB<-matrix(NA, nrow=10000, ncol=1000)                                                
mu.estB<-matrix(NA, nrow=10000, ncol=1000)       
Po.estB<-matrix(NA, nrow=10000, ncol=1000)   

# Set other covariates fix, only NDVI has a gradient
mean.x = mean(Pred.tableTC$x)#Don't forget! x are /1000
## Extinct = A
for (i in 1:1000){
  p.estA[,i]<-plogis(PA.Int.est[,i]+NDVI.seq[i]*PA.slope.est[,i]+PA.x.est[,i]*mean.x+0)
  mu1.estA[,i]<-exp(Cnt.Int.est[,i]+NDVI.seq[i]*Cnt.slope.est[,i]+Cnt.x.est[,i]*mean.x+0)
  Po.estA[,i]<-(theta/(mu1.estA[,i]+theta))^theta   
}
mu.estA<- (p.estA/(1-Po.estA)) * mu1.estA
## Extinct = B
for (i in 1:1000){
  p.estB[,i]<-plogis(PA.Int.est[,i]+NDVI.seq[i]*PA.slope.est[,i]+PA.x.est[,i]*mean.x+PA.ExtB.est[,i])
  mu1.estB[,i]<-exp(Cnt.Int.est[,i]+NDVI.seq[i]*Cnt.slope.est[,i]+Cnt.x.est[,i]*mean.x+Cnt.ExtB.est[,i])
  Po.estB[,i]<-(theta/(mu1.estB[,i]+theta))^theta   
}
mu.estB<- (p.estB/(1-Po.estB)) * mu1.estB

reg.estA<-data.frame(NDVI.seq=NDVI.seq, p.est.mean=colMeans(p.estA), mu1.est.mean=colMeans(mu1.estA), mu.est.mean=colMeans(mu.estA))
reg.estB<-data.frame(NDVI.seq=NDVI.seq, p.est.mean=colMeans(p.estB), mu1.est.mean=colMeans(mu1.estB), mu.est.mean=colMeans(mu.estB))

for (i in 1:1000){
  reg.estA$mu.est.lower2.5[i]<-quantile(mu.estA[,i], probs = 0.025)
  reg.estA$mu.est.upper97.5[i]<-quantile(mu.estA[,i], probs = 0.975)
  reg.estB$mu.est.lower2.5[i]<-quantile(mu.estB[,i], probs = 0.025)
  reg.estB$mu.est.upper97.5[i]<-quantile(mu.estB[,i], probs = 0.975)
} 

# plot
plot(reg.estA$NDVI.seq,reg.estA$mu.est.mean*1000/240, type="l", lwd=2) 
lines(reg.estA$NDVI.seq,reg.estA$mu.est.lower2.5*1000/240, type="l", lty=2, lwd=2) 
lines(reg.estA$NDVI.seq,reg.estA$mu.est.upper97.5*1000/240, type="l", lty=2, lwd=2) 

points(reg.estB$NDVI.seq,reg.estB$mu.est.mean*1000/240, type="l", lwd=2, col="red4") 
lines(reg.estB$NDVI.seq,reg.estB$mu.est.lower2.5*1000/240, type="l", lty=2, lwd=2, col="red4") 
lines(reg.estB$NDVI.seq,reg.estB$mu.est.upper97.5*1000/240, type="l", lty=2, lwd=2, col="red4") 


#### ~ Predict management areas ####

####### COMBINE DS and TC ####
### ~ Plot prediction curve for DS and TC ####
head(DSpred)
head(DSpred.se)
head(reg.estA$mu.est.mean)
head(reg.estB$mu.est.mean)
### ~ Figure 2 ###
redtrans <- rgb(255, 0, 0, 30, maxColorValue=255) 
km<-1000/240 # to obtain km2
#tiff("Figure 2_LeMoullec2019.tiff", res = 300, width=16, height=10, units="in", compression="lzw+p")
par(mfrow=c(1,2),mar=(c(5,5,4,4)+0.1),bty="n")
plot(mod.sel,which=2,axes=FALSE,xlab = "",pch=16,lwd=2) 
axis(1,cex.axis=2,lwd=2,at=seq(0,1000,200),line=-1)
axis(2,cex.axis=2,lwd=2,line=-1)
mtext(1, text= "Distance (m)", line=1.6, cex=2,family="sans")
mtext(2, text= "Detection probability",line=1.6, cex=2)
text(1000,0.23,"Sunny", cex=1.5,xpd=NA) #
text(1000,0.14,"Mix", cex=1.5,xpd=NA)
text(1000,0.04,"Cloudy", cex=1.5,xpd=NA)
text(900,1,"(A)",cex=2,xpd=NA)

par(mar=(c(5,5,4,4)+0.1),bty="n")
plot(DSpred*km~NDVI.seq,xlab="",ylab="",axes=F,type="n",ylim=c(-0.2,7),xlim=c(0,838))
polygon(c(NDVI.seq,rev(NDVI.seq)),c(DSpred*km-1.96*DSpred.se*km,rev(DSpred*km+1.96*DSpred.se*km)),col=redtrans,border=NA)
polygon(c(NDVI.seq,rev(NDVI.seq)),c(reg.estA$mu.est.lower2.5*km,rev(reg.estA$mu.est.upper97.5*km)),col='grey80',border=NA)
polygon(c(NDVI.seq,rev(NDVI.seq)),c(reg.estB$mu.est.lower2.5*km,rev(reg.estB$mu.est.upper97.5*km)),col='grey50',border=NA)
lines(reg.estA$mu.est.mean*km~reg.estA$NDVI.seq, type="l",lwd=2, col="grey40") 
lines(reg.estB$mu.est.mean*km~reg.estB$NDVI.seq, type="l", lwd=2) 
lines(DSpred*km~NDVI.seq,lwd=3,col=alpha("red4",0.5),lty=2)
axis(2,cex.axis=2,lwd=2,las=2)
mtext(expression(paste("Reindeer density "," ",km^2)),2,cex=2,line=3)

segments(x0=c(TCforGLM$NDVI),y0=rep(-0.2,length(TCforGLM$NDVI)),x1=c(TCforGLM$NDVI),y1=rep(0,length(TCforGLM$NDVI)),col="green4")
segments(x0=c(Seg_data$NDVI),y0=rep(-0.2,length(Seg_data$NDVI)),x1=c(Seg_data$NDVI),y1=rep(0,length(Seg_data$NDVI)),col="red4")

axis(1,cex.axis=2,lwd=2,at=seq(0,800,200),labels=seq(0,0.8,0.2),line=-0.5)
mtext("NDVI",1,cex=2,line=2)
legend(30,7,c("Distance Sampling","Total counts / Past extinction","Total counts / No extinction"),col=c("red4","grey50","black"),lty=c(2,1,1),lwd=c(3,2,2),text.col=c("red4","grey50","black"),cex=1.5,bty="n")
text(750,7,"(B)",cex=2,xpd=NA)
lines(DSpred*km~NDVI.seq,lwd=3,col=alpha("red4",0.5),lty=2)

dev.off()

#### ~ Predict SYS Management areas 1 to 13 #####
head(SYSArea_pred.table)

SYSarea<-unique(SYSArea_pred.table$Area)
SYSpred<-data.frame(SYSarea=rep(NA,13),SYSareaKm2=rep(NA,13),DS.pred=rep(NA,13),DS.SE=rep(NA,13),DS.var=rep(NA,13),DS.cv=rep(NA,13),
                    TC.pred=rep(NA,13),TC.SE=rep(NA,13),TC.var=rep(NA,13),TC.cv=rep(NA,13),Diff=rep(NA,13),Diff.low=rep(NA,13),Diff.up=rep(NA,13),
                    SE.Diff=rep(NA,13),Z=rep(NA,13),P=rep(NA,13))

for (i in 1:13){
  Cov.tab<-SYSArea_pred.table[SYSArea_pred.table$Area==SYSarea[i],]
  SYSpred$SYSarea[i]<-as.character(SYSarea[i])
  SYSpred$SYSareaKm2[i]<-(length(na.omit(Cov.tab$NDVI))*240*240)*10^-6
  PredDS<-dsm.var.gam(SK1,Cov.tab,off.set=240*240) # Set off.set according to resolution
  SYSpred$DS.pred[i]<-unlist(PredDS$pred)
  SYSpred$DS.var[i]<-PredDS$pred.var
  SYSpred$DS.SE[i]<-sqrt(PredDS$pred.var)
  SYSpred$DS.cv[i]<-sqrt(PredDS$pred.var)/unlist(PredDS$pred)
  
  Cov.tab$x<-Cov.tab$x/10000 #need to rescale x to make it work with ZANB
  ### Exctinction = A
  #PA model
  Cov.tabA<-Cov.tab[Cov.tab$Extinct=="A",]
  PA<-coef(ZANB,model="zero") # PA part
  g<-PA[1]+PA[2]*Cov.tabA$NDVI+PA[3]*Cov.tabA$x+0 # region A
  p<-exp(g)/(1+exp(g)) #backtrasform of logit
  #Count model
  theta<-ZANB$theta
  Cnt<-coef(ZANB,model="count") # count part
  gc<-Cnt[1]+Cnt[2]*Cov.tabA$NDVI+Cnt[3]*Cov.tabA$x+0 # region A
  mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
  # Combine
  Po<-(theta/(mu1+theta))^theta
  muZANB.A<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1
  varZANB.A<-(p/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-((p/(1-Po))*mu1)^2 # # NOT AS IN ZUUR p 288:((1-p)/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-(((1-p)/(1-Po))*mu1)^2
  ### Exctinction = B Not extinct
  Cov.tabB<-Cov.tab[Cov.tab$Extinct=="B",]
  g<-PA[1]+PA[2]*Cov.tabB$NDVI+PA[3]*Cov.tabB$x+PA[4] # region B
  p<-exp(g)/(1+exp(g)) #backtrasform of logit
  #Count model
  gc<-Cnt[1]+Cnt[2]*Cov.tabB$NDVI+Cnt[3]*Cov.tabB$x+Cnt[4] # region B
  mu1<- exp(gc) # for backtransforming both the poisson and negbin!!!
  # Combine
  Po<-(theta/(mu1+theta))^theta
  muZANB.B<-(p/(1-Po))*mu1 # mu<-muNB*(1-p) for Poisson # NOT AS IN ZUUR p 288: ((1-p)/(1-Po))*mu1
  varZANB.B<-(p/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-((p/(1-Po))*mu1)^2 # # NOT AS IN ZUUR p 288:((1-p)/(1-Po))*(mu1^2+mu1+(mu1^2)/theta)-(((1-p)/(1-Po))*mu1)^2
  
  SYSpred$TC.pred[i]<-sum(muZANB.A)+sum(muZANB.B) #
  SYSpred$TC.var[i]<-sum(varZANB.A)+sum(varZANB.B)
  SYSpred$TC.SE[i]<-sqrt(sum(varZANB.A)+sum(varZANB.B))
  SYSpred$TC.cv[i]<-SYSpred$TC.SE[i]/SYSpred$TC.pred[i]
  
  # TC and DA Difference
  SYSpred$Diff[i]<-SYSpred$TC.pred[i]-SYSpred$DS.pred[i]
  SYSpred$SE.Diff[i]<-sqrt((SYSpred$TC.SE[i])^2+(SYSpred$DS.SE[i])^2)
  SYSpred$Z[i]<-abs(SYSpred$Diff[i]/SYSpred$SE.Diff[i])
  SYSpred$P[i]<-2*pnorm(SYSpred$Z[i],lower.tail=FALSE)
  SYSpred$Diff.up[i]<-qnorm(0.975,mean=SYSpred$Diff[i],sd=SYSpred$SE.Diff[i])
  SYSpred$Diff.low[i]<-qnorm(0.025,mean=SYSpred$Diff[i],sd=SYSpred$SE.Diff[i])
}
head(SYSpred)


#### ~ weighted average, Overall mean population size ####

#mean(lambda) = ( lambda_TC/sigma_TC + lambda_DS/sigma_DS) / (1/ sigma_TC + 1/ sigma_DS)
ds.N=21079
tc.N=22615
ds.se=2983
tc.se=401
meanN=(tc.N/tc.se + ds.N/ds.se)/(1/tc.se + 1/ds.se)
DS.N.sim<-rnorm(10000,mean=ds.N,sd=ds.se)
TC.N.sim<-rnorm(10000,mean=tc.N,sd=tc.se)
meanN.sim=(TC.N.sim/sd(TC.N.sim) + DS.N.sim/sd(DS.N.sim))/(1/sd(TC.N.sim) + 1/sd(DS.N.sim))

mean(meanN.sim)
quantile(meanN.sim, probs = 0.025)
quantile(meanN.sim, probs = 0.975)
#22,435 (95% CI = 21,452-23,425)

### weighted average per pixel
p<-read.delim("Prediction.Svalbard.published.txt")
head(p)

p$Wmean<-rep(NA,length(p$x))
p$Wmean.se<-rep(NA,length(p$x))
for(i in 1:length(p$x))
{
DS.N.sim<-rnorm(1000,mean=p$DSpred[i],sd=p$DSpred.se[i])
TC.N.sim<-rnorm(1000,mean=p$TCpred[i],sd=p$TCpred.se[i])
meanN.sim=(TC.N.sim/sd(TC.N.sim) + DS.N.sim/sd(DS.N.sim))/(1/sd(TC.N.sim) + 1/sd(DS.N.sim))
p$Wmean[i]<-mean(meanN.sim)
p$Wmean.se[i]<- sd(meanN.sim)
}
